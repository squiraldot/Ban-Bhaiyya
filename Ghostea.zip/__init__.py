# Ghostea project root.
